AppGiniPlugin.language = AppGiniPlugin.language || {};
AppGiniPlugin.language.en = $j.extend(AppGiniPlugin.language.en, {
	


	/*************************************************************/
	end_place_holder: '--- Please keep this line at the end of the file! ---'
})
