			<?php echo $messages->git_branch(); ?>
		</div> <!-- /div.container -->
	</body>
</html>
