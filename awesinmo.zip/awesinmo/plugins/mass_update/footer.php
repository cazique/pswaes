			<?php echo $mass_update->git_branch(); ?>
		</div> <!-- /div.container -->
	</body>
</html>
