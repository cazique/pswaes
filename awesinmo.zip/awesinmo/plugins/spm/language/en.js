AppGiniPlugin.language = AppGiniPlugin.language || {};
AppGiniPlugin.language.en = $j.extend(AppGiniPlugin.language.en, {
	CREATE_SEARCH_PAGE: 'CREATE SEARCH PAGES',
	


	/*************************************************************/
	end_place_holder: '--- Please keep this line at the end of the file! ---'
})
