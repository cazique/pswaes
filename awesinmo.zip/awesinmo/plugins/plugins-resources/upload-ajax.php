<?php
	include(__DIR__ . '/loader.php');
	
	$plugin = new AppGiniPlugin();
	$plugin->process_ajax_upload();